package com.example.sign_language_recognition

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
